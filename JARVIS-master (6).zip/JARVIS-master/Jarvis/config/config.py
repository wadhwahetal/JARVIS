email = "prathameshdevkate1802@gmail.com"
email_password = "Prathamesh@123"
wolframalpha_id = "7RKYLQ-65VW8374X3"
weather_api_key = "0ecbd5a740d3da8cdfe9d6a5ed2c2512"